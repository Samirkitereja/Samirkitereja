#include<iostream>
using namespace std;

int main()
{
    int num;
    int sum = 0;
    
    cout <<"enter number:  ";
    cin>> num;
    while (num>=0)
    {
    sum += num;
    cout<<"enter number:  ";
    cin>> num;
    }
    cout<<"sum is: "<<sum<<endl;
    return 0;
}