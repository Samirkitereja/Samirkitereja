#include<iostream>
using namespace std;

int main()
{
   int a;
   int b;
  int gcd;

cout<<"enter the first number: ";
cin>> a;
cout<<"enter the second number: ";
cin>> b;

while(a!=b){
if(a>b){
a-=b;
}else{
b-=a;
}

}

cout<<"The GCD is: "<< a;
    return 0;
}