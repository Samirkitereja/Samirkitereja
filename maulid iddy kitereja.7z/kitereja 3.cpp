#include <iostream>
using namespace std;

int main() {
   int sum = 0;
   double avg;
    int n = 200;

   for(int i = 1; i <= n; ++i) {
      sum += i;
   }
avg = sum/n;
   cout << "The avg of the first 200 natural numbers is: " << avg << endl;
   return 0;
}
    